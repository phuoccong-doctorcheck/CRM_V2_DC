/* eslint-disable @typescript-eslint/no-unused-vars */

import React, { useState } from 'react';

interface TagSettingProps {
}

const TagSetting: React.FC<TagSettingProps> = ({ }) => {

  return (
    <div className="t-tags">

    </div>
  );
};

// TagSetting.defaultProps = {
// };

export default TagSetting;
