/* eslint-disable @typescript-eslint/no-unused-vars */


import React, { useState } from "react";

interface CampaignTemplateSettingProps { }

const CampaignTemplateSetting: React.FC<CampaignTemplateSettingProps> = ({

}) => {

  return (
    <div className="t-campaign_template">

    </div>
  );
};

CampaignTemplateSetting.defaultProps = {};

export default CampaignTemplateSetting;
